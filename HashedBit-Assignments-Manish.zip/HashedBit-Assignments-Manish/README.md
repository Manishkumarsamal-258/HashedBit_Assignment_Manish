# HashedBit-Assignments

1) HTML and CSS
2) JS Assignment 1 - Solve
3) JS Assignment 2
4) JS Assignment 3
5) 	JS Assignment 4 - DOM
6) 	JS Assignment 5 - DOM
7) 	JS Assignment 6 - Stopwatch
8) 	JS Assignment 7 - Modal
9) 	JS Assignment 8 - IPL Points Table - API Call and Display
10) 	React Assignment 1 - Calculator
11) 	React Assignment 2 - Registration Form
12) 	React Assignment 3 - Survey Form
13) 	React - To Do App
