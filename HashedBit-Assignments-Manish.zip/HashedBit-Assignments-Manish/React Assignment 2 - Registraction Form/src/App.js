import './App.css';
import RegistrationForm from './Components/RegistrationForm';

function App() {
  return (
    <>
    <RegistrationForm/>
    </>
  );
}

export default App;