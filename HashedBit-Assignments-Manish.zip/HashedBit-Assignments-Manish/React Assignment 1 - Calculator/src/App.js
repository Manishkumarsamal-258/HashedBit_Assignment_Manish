import './App.css';
import Calculator from './component/Calculator.js';

function App() {
  return (
    <div className="App">
      <Calculator/>
    </div>
  );
}

export default App;