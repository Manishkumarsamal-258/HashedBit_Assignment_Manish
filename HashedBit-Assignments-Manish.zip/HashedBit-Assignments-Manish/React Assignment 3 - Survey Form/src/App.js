import Form from "./components/Form";

export default function App() {
  return (
    <>
      <Form />
    </>
  );
}